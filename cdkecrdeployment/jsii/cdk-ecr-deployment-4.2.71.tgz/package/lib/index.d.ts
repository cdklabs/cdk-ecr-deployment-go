import { aws_ec2 as ec2, aws_iam as iam } from 'aws-cdk-lib';
import { PolicyStatement, AddToPrincipalPolicyResult } from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
export interface ECRDeploymentProps {
    /**
     * The source of the docker image.
     */
    readonly src: IImageName;
    /**
     * The destination of the docker image.
     */
    readonly dest: IImageName;
    /**
     * The image architecture to be copied.
     *
     * The 'amd64' architecture will be copied by default. Specify the
     * architecture or architectures to copy here.
     *
     * It is currently not possible to copy more than one architecture
     * at a time: the array you specify must contain exactly one string.
     *
     * @default ['amd64']
     */
    readonly imageArch?: string[];
    /**
     * Whether to copy a source docker image index (multi-arch manifest) to the destination.
     *
     * When true, copies the image index and all underlying architecture-specific
     * images in a single operation.
     *
     * @default False
     */
    readonly copyImageIndex?: boolean;
    /**
     * Tags to apply to individual architecture-specific images when
     * copyImageIndex is true.
     *
     * Can only be specified when copyImageIndex is true. Maps architecture names to
     * their respective tags. This makes individual architectures discoverable
     * by human-readable tags in addition to the image index tag.
     *
     * For example, { 'arm64': 'image-arm64', 'amd64': 'image-amd64' }.
     */
    readonly archImageTags?: {
        [architecture: string]: string;
    };
    /**
     * Retry configuration to apply to when copying images such as the number of retry attemtps,
     * the base amount of delay (in seconds) between each retry, and the max amount of delay (in seconds)
     * between each retry.
     *
     * For example, { 'numAttempts': 3, 'baseDelay': 1, 'maxDelay': 5 }
     */
    readonly retryConfigs?: {
        [fields: string]: number;
    };
    /**
     * The amount of memory (in MiB) to allocate to the AWS Lambda function which
     * replicates the files from the CDK bucket to the destination bucket.
     *
     * If you are deploying large files, you will need to increase this number
     * accordingly.
     *
     * @default - 512
     */
    readonly memoryLimit?: number;
    /**
     * Execution role associated with this function
     *
     * @default - A role is automatically created
     */
    readonly role?: iam.IRole;
    /**
     * The VPC network to place the deployment lambda handler in.
     *
     * @default - None
     */
    readonly vpc?: ec2.IVpc;
    /**
     * Where in the VPC to place the deployment lambda handler.
     * Only used if 'vpc' is supplied.
     *
     * @default - the Vpc default strategy if not specified
     */
    readonly vpcSubnets?: ec2.SubnetSelection;
    /**
     * The list of security groups to associate with the Lambda's network interfaces.
     *
     * Only used if 'vpc' is supplied.
     *
     * @default - If the function is placed within a VPC and a security group is
     * not specified, either by this or securityGroup prop, a dedicated security
     * group will be created for this function.
     */
    readonly securityGroups?: ec2.SecurityGroup[];
}
export interface IImageName {
    /**
     *  The uri of the docker image.
     *
     *  The uri spec follows https://github.com/containers/skopeo
     */
    readonly uri: string;
    /**
     * The credentials of the docker image. Format `user:password` or `AWS Secrets Manager secret arn` or `AWS Secrets Manager secret name`.
     *
     * If specifying an AWS Secrets Manager secret, the format of the secret should be either plain text (`user:password`) or
     * JSON (`{"username":"<username>","password":"<password>"}`).
     *
     * For more details on JSON format, see https://docs.aws.amazon.com/AmazonECS/latest/developerguide/private-auth.html
     */
    creds?: string;
}
export declare class DockerImageName implements IImageName {
    private name;
    creds?: string | undefined;
    /**
     * @param name - The name of the image, e.g. retrieved from `DockerImageAsset.imageUri`
     * @param creds - The credentials of the docker image. Format `user:password` or `AWS Secrets Manager secret arn` or `AWS Secrets Manager secret name`.
     *     If specifying an AWS Secrets Manager secret, the format of the secret should be either plain text (`user:password`) or
     *     JSON (`{"username":"<username>","password":"<password>"}`).
     *     For more details on JSON format, see https://docs.aws.amazon.com/AmazonECS/latest/developerguide/private-auth.html
     */
    constructor(name: string, creds?: string | undefined);
    get uri(): string;
}
export declare class S3ArchiveName implements IImageName {
    creds?: string | undefined;
    private name;
    /**
     * @param p - the S3 bucket name and path of the archive (a S3 URI without the s3://)
     * @param ref - appended to the end of the name with a `:`, e.g. `:latest`
     * @param creds - The credentials of the docker image. Format `user:password` or `AWS Secrets Manager secret arn` or `AWS Secrets Manager secret name`.
     *     If specifying an AWS Secrets Manager secret, the format of the secret should be either plain text (`user:password`) or
     *     JSON (`{"username":"<username>","password":"<password>"}`).
     *     For more details on JSON format, see https://docs.aws.amazon.com/AmazonECS/latest/developerguide/private-auth.html
     */
    constructor(p: string, ref?: string, creds?: string | undefined);
    get uri(): string;
}
export declare class ECRDeployment extends Construct {
    private handler;
    constructor(scope: Construct, id: string, props: ECRDeploymentProps);
    addToPrincipalPolicy(statement: PolicyStatement): AddToPrincipalPolicyResult;
    private renderSingletonUuid;
}
